
import sqlite3

# Connect to SQLite database (or create it if not exists)
conn = sqlite3.connect('event_management.db')
cursor = conn.cursor()

# Create tables if they don't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name TEXT NOT NULL,
    event_date TEXT NOT NULL,
    location TEXT NOT NULL
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS participants (
    participant_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    event_id INTEGER,
    FOREIGN KEY (event_id) REFERENCES events (event_id)
)
''')

conn.commit()

# Functions
def add_event():
    name = input("Enter Event Name: ")
    date = input("Enter Event Date (YYYY-MM-DD): ")
    location = input("Enter Location: ")
    cursor.execute("INSERT INTO events (event_name, event_date, location) VALUES (?, ?, ?)", (name, date, location))
    conn.commit()
    print("✅ Event added successfully!\n")

def view_events():
    cursor.execute("SELECT * FROM events")
    events = cursor.fetchall()
    if events:
        print("\nAll Events:")
        for event in events:
            print(f"ID: {event[0]} | Name: {event[1]} | Date: {event[2]} | Location: {event[3]}")
    else:
        print("⚠️ No events found.\n")

def register_participant():
    view_events()
    event_id = input("Enter Event ID to register for: ")
    name = input("Enter Participant Name: ")
    email = input("Enter Participant Email: ")
    cursor.execute("INSERT INTO participants (name, email, event_id) VALUES (?, ?, ?)", (name, email, event_id))
    conn.commit()
    print("✅ Participant registered successfully!\n")

def view_participants():
    view_events()
    event_id = input("Enter Event ID to view participants: ")
    cursor.execute("SELECT name, email FROM participants WHERE event_id = ?", (event_id,))
    participants = cursor.fetchall()
    if participants:
        print(f"\nParticipants for Event ID {event_id}:")
        for p in participants:
            print(f"Name: {p[0]} | Email: {p[1]}")
    else:
        print("⚠️ No participants found for this event.\n")

# Main Menu
def main():
    while True:
        print("\n===== Event Management System =====")
        print("1. Add New Event")
        print("2. View All Events")
        print("3. Register Participant")
        print("4. View Participants by Event")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            add_event()
        elif choice == '2':
            view_events()
        elif choice == '3':
            register_participant()
        elif choice == '4':
            view_participants()
        elif choice == '5':
            print("Goodbye! 👋")
            break
        else:
            print("Invalid choice. Please try again.")

    conn.close()

if __name__ == "__main__":
    main()

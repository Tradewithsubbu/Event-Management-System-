
# 🎉 Event Management System (Python + SQLite)

A simple **console-based Event Management System** built using Python and SQLite for managing events and participants.

## ✅ Features
- Add New Event
- View All Events
- Register Participants for Events
- View Participants for a Selected Event

## ⚙️ Technologies Used
- Python 3
- SQLite (for database)

## 📂 Project Structure
```
Event-Management-System/
 ┣ 📄 event_management.py     # Main code
 ┗ 📄 event_management.db     # SQLite DB file (auto-created)
```

## ▶️ How to Run
1. Clone the repo or download files
2. Run:
```
python event_management.py
```
3. Follow the menu to interact with the system.

## 📧 Contact
Developed by **Shubham Ahirwar**
